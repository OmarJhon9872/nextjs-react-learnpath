export default function Page(){
    return (<p>Customers Page</p>)
}